# FFXI Galka Cockpit & Tarutaru Pilot 3D Module

A standalone, modular 3D asset designed to bring the **Galka Mech** concept to life in *Final Fantasy XI*.

Based on the [FFXIAH Galka Mech Concept](https://www.ffxiah.com/forum/topic/59135/galka-mech/#3799039), this module places a fully modeled 3D cockpit into the chest of any Galka body armor with an adorable Tarutaru pilot at the dual joystick controls.

---

## 📦 Package Contents

1. **`galka_cockpit_module.glb`**
   - Universal GLTF binary with pre-assigned FFXI Galka bone skinning (`bone0038: 0.85` chest, `bone0037: 0.15` spine).
   - Fully compliant with FFXI Direct3D 8 vertex limits ($\le 2$ bones per vertex, 100% normalized).
   - 2,321 vertices / 3,936 polygons.
2. **`galka_cockpit_module.obj` & `galka_cockpit_module.mtl`**
   - Standard static Wavefront OBJ/MTL geometry for any 3D software (Blender, Maya, 3ds Max).
3. **`tim_gal_cockpit_atlas.png`**
   - High-fidelity 256x256 texture atlas containing:
     - **Top-Left (128x128)**: Starry Blue Bandana (5 golden stars) & Caramel Taru Face with smiling brown eyes.
     - **Top-Right (128x128)**: White Cotton T-Shirt with Cartoon Meat Skewer (Kebab) logo.
     - **Bottom-Left (128x128)**: Steampunk Cockpit Interior: Warm incandescent lantern, parchment dial gauge with red needle, dual flight sticks with red/amber ball knobs.
     - **Bottom-Right (128x128)**: Polished Brass Bezel Ring with 8 individual 3D hex bolts.
4. **`attach_cockpit_to_galka_body.py`**
   - Automated one-command Python script for Blender that merges this cockpit module onto ANY Galka body DAT/GLB automatically.
5. **Render Previews**
   - `galka_cockpit_module_preview.png`: Direct front view showing the pilot and control sticks.
   - `galka_cockpit_module_angle.png`: 3/4 perspective showing the cockpit depth and bulkhead.

---

## ⚡ Option 1: Automated 1-Click Merge (Recommended)

You can automatically attach this cockpit to any Galka body GLB using the included script and Blender CLI:

```bash
blender --background --python attach_cockpit_to_galka_body.py -- <galka_body.glb> <galka_texture.png> [output.glb] [output_atlas.png]
```

### What the Script Does Automatically:
1. Builds a combined 256x256 texture atlas (Left half = Galka armor, Right half = Cockpit module).
2. Excises a precise mathematical circular hole ($r = 0.120\text{m}$) in the Galka's chest using a Boolean Difference cylinder.
3. Aligns the cockpit module, remaps UV coordinates, and joins the meshes.
4. Enforces the strict FFXI hardware skinning limit ($\le 2$ bones per vertex, normalized).
5. Exports a clean `.glb` ready to be imported directly into your DAT with `xi gear import`!

---

## 🛠️ Option 2: Manual Blender Integration

If you prefer to manually customize or position the module:

1. **Import Galka Body**: In Blender, import your exported Galka body `.glb` or `.obj`.
2. **Import Cockpit**: Import `galka_cockpit_module.glb`. The module is already positioned at the Galka chest center:
   - **X**: `0.293` (Front chest depth)
   - **Y**: `0.000` (Centerline)
   - **Z**: `1.602` (Mid-sternum height)
3. **Cut Aperture**:
   - Create a Cylinder at `(0.293, 0.0, 1.602)` with radius `0.120`, depth `0.5`, rotated 90° on the Y-axis.
   - Add a **Boolean** modifier (`Difference`, `Exact`) to the Galka body mesh targeting the cylinder, and Apply.
4. **Texture Atlas**:
   - Scale your Galka body UVs by 0.5 horizontally (`u = u * 0.5`).
   - Scale the Cockpit UVs by 0.5 and offset by 0.5 (`u = 0.5 + u * 0.5`).
   - Combine the textures side-by-side into a single 256x256 image.
5. **Join & Skin**:
   - Select the Cockpit module, Shift-select the Galka body, and press `Ctrl + J` to join.
   - Run `Vertex Group Limit Total = 2` and `Normalize All` to avoid game crashes.
6. **Export & Compile**:
   - Export as GLTF/GLB with skins enabled.
   - Inject into your DAT using `xi-tools` or `Noesis`.

---

## 🎮 In-Game DAT Import Example (xi-tools)

```bash
# Import the merged GLB into the DAT:
xi gear import --target 58.DAT --mesh galka_body_with_cockpit.glb

# Import the combined texture atlas:
xi tex import --target 58.DAT --index 0 --image galka_body_atlas.png
```

Enjoy piloting your Galka from within! 🤖🍢
